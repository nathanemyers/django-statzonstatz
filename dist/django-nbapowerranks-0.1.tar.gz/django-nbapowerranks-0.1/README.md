#NBA POWER RANKINGS

Special Thanks to http://forrestthewoods.com/unbalanced-design-of-super-smash-brothers/ for inspiring me to create this.


##2014
This is my initial stab at creating the power rankings. Based heavily on the smash bros code.

Data is store in a local json files and is completely recompiled every week

##2015
Currently integrated into a django app, right now I'm working on decoupling and migrating the backend
to Flask (http://flask.pocoo.org/) and MariaDB (https://mariadb.org/)
